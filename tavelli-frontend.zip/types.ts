export enum EmailCategory {
  IMPORTANT = 'IMPORTANT',
  TEMPORARY_IMPORTANT = 'TEMPORARY_IMPORTANT',
  PROMOTION = 'PROMOTION',
  SOCIAL = 'SOCIAL',
  SPAM = 'SPAM'
}

export interface Email {
  id: string;
  senderName: string;
  senderEmail: string;
  subject: string;
  snippet: string;
  body: string; // Full HTML/Text content
  date: string;
  isRead: boolean;
  category: EmailCategory;
  tags?: string[];
  logoUrl?: string; // For Enterprise features
}

export interface UserPlan {
  type: 'FREE' | 'PRO' | 'ENTERPRISE';
  price: number;
  features: string[];
}

export interface AIAnalysisResult {
  summary: string;
  suggestedReply?: string;
  actionButtons: AIActionButton[];
  sentiment: 'positive' | 'neutral' | 'negative' | 'urgent';
}

export interface AIActionButton {
  label: string;
  type: 'copy_code' | 'verify_link' | 'draft_reply' | 'unsubscribe';
  value: string; // The code to copy, link to open, or prompt for reply
  primary: boolean;
}

// --- New Types for History & Settings ---

export interface HistoryItem {
  id: string;
  actionType: 'reply' | 'summary' | 'action';
  description: string;
  targetEmail: string;
  timestamp: string;
  aiStyle?: string;
}

export interface AppSettings {
  language: 'en' | 'ru';
  theme: 'dark' | 'light';
  aiStyle: 'strict' | 'human' | 'humor';
  customPrompt: string;
  logoUrl: string | null;
  logoPosition: 'start' | 'end';
}

export interface Account {
  id: string;
  email: string;
  name: string;
  avatar: string;
  isActive: boolean;
}