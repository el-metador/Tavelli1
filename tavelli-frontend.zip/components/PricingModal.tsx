import React from 'react';
import { UserPlan } from '../types';

interface PricingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectPlan: (plan: UserPlan['type']) => void;
  currentPlanType: string;
}

const PricingModal: React.FC<PricingModalProps> = ({ isOpen, onClose, onSelectPlan, currentPlanType }) => {
  if (!isOpen) return null;

  const tiers = [
    {
      type: 'FREE',
      price: '$0',
      period: '/mo',
      features: ['Basic AI Filtering', '7-day History Analysis', '1 Account'],
      color: 'gray'
    },
    {
      type: 'PRO',
      price: '$4.50',
      period: '/mo',
      features: ['Advanced AI Analysis', '3 Accounts Linked', 'Priority Hot Actions', 'Smart Summaries'],
      color: 'blue'
    },
    {
      type: 'ENTERPRISE',
      price: '$10.00',
      period: '/mo',
      features: ['10 Accounts Linked', 'Custom Brand Voice', 'Auto-Logo Generator', 'Deep History Search', 'Priority Support'],
      color: 'purple'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm transition-opacity" onClick={onClose}></div>
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-4xl overflow-hidden relative z-10 flex flex-col md:flex-row">
        
        <button onClick={onClose} className="absolute top-4 right-4 p-2 text-gray-400 hover:bg-gray-100 rounded-full z-20">
          <span className="material-symbols-rounded">close</span>
        </button>

        <div className="p-8 md:p-12 w-full">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Upgrade Tavelli</h2>
            <p className="text-gray-500">Unlock the full power of AI for your inbox.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {tiers.map((tier) => (
              <div 
                key={tier.type}
                className={`relative p-6 rounded-2xl border transition-all duration-300 hover:-translate-y-1 ${
                  currentPlanType === tier.type 
                    ? `border-${tier.color}-500 ring-1 ring-${tier.color}-500 bg-${tier.color}-50/30` 
                    : 'border-gray-200 hover:shadow-xl hover:border-transparent'
                }`}
              >
                {currentPlanType === tier.type && (
                  <div className={`absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full text-xs font-bold text-white bg-${tier.color}-600`}>
                    CURRENT
                  </div>
                )}
                <div className="text-center mb-6">
                  <h3 className={`text-sm font-bold uppercase tracking-widest text-${tier.color}-600 mb-2`}>{tier.type}</h3>
                  <div className="flex items-baseline justify-center">
                    <span className="text-4xl font-bold text-gray-900">{tier.price}</span>
                    <span className="text-gray-500 text-sm">{tier.period}</span>
                  </div>
                </div>
                <ul className="space-y-3 mb-8">
                  {tier.features.map((feat, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm text-gray-600">
                      <span className={`material-symbols-rounded text-sm text-${tier.color}-500`}>check_circle</span>
                      {feat}
                    </li>
                  ))}
                </ul>
                <button
                  onClick={() => {
                    onSelectPlan(tier.type as UserPlan['type']);
                    onClose();
                  }}
                  className={`w-full py-3 rounded-xl font-bold text-sm transition-colors ${
                    tier.type === 'ENTERPRISE' ? 'bg-purple-600 text-white hover:bg-purple-700' :
                    tier.type === 'PRO' ? 'bg-blue-600 text-white hover:bg-blue-700' :
                    'bg-gray-100 text-gray-800 hover:bg-gray-200'
                  }`}
                >
                  {currentPlanType === tier.type ? 'Active Plan' : `Choose ${tier.type}`}
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PricingModal;