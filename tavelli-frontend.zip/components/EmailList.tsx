import React from 'react';
import { Email, EmailCategory } from '../types';

interface EmailListProps {
  emails: Email[];
  onSelectEmail: (email: Email) => void;
  strictMode: boolean;
  setStrictMode: (val: boolean) => void;
  isProcessing: boolean;
  onToggleSidebar: () => void;
  onCompose: () => void;
}

const EmailList: React.FC<EmailListProps> = ({ emails, onSelectEmail, strictMode, setStrictMode, isProcessing, onToggleSidebar, onCompose }) => {
  
  // Filter logic based on Strict Mode
  const filteredEmails = emails.filter(email => {
    if (!strictMode) return true;
    return (
      email.category === EmailCategory.IMPORTANT || 
      email.category === EmailCategory.TEMPORARY_IMPORTANT
    );
  });

  return (
    <div className="flex-1 flex flex-col h-full bg-[#111111] relative">
      {/* Top Search Bar Area - Sticky & Glassy */}
      <div className="px-4 py-3 sticky top-0 z-20 bg-[#111111]/95 backdrop-blur-md">
        <div className="flex items-center bg-[#2b2c2f] rounded-full px-2 pr-4 h-12 shadow-sm transition-colors hover:bg-[#303134]">
          <button onClick={onToggleSidebar} className="p-3 text-gray-200 rounded-full hover:bg-gray-600/20">
            <span className="material-symbols-rounded">menu</span>
          </button>
          
          <input 
            type="text" 
            placeholder="Search in mail" 
            className="flex-1 bg-transparent border-none focus:ring-0 text-gray-200 placeholder-gray-400 text-[16px] px-2"
          />
          
          <div className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center text-white font-medium text-sm border border-purple-400">
            T
          </div>
        </div>
        
        <div className="flex items-center justify-between mt-3 px-1">
          <h2 className="text-[#c4c7c5] text-[11px] font-medium uppercase tracking-widest pl-1">All inboxes</h2>
          
          {/* Strict Filter Toggle (styled as a chip) */}
          <button 
            onClick={() => setStrictMode(!strictMode)}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-lg border text-xs font-medium transition-all ${
              strictMode 
                ? 'bg-[#004a77] border-[#004a77] text-[#c2e7ff]' 
                : 'bg-transparent border-[#444746] text-[#c4c7c5]'
            }`}
          >
             <span className="material-symbols-rounded text-[16px]">{strictMode ? 'check' : 'filter_list'}</span>
             Strict Mode
          </button>
        </div>
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto pb-24 px-1">
        {filteredEmails.length === 0 ? (
          <div className="flex flex-col items-center justify-center pt-20 text-[#c4c7c5]">
             <span className="material-symbols-rounded text-6xl mb-4 opacity-20">inbox</span>
             <p>Nothing in strict mode.</p>
          </div>
        ) : (
          <div className="flex flex-col gap-1">
            {filteredEmails.map((email) => {
              // Extract first letter for avatar
              const initial = email.senderName.charAt(0).toUpperCase();
              // Mock colors based on ID
              const colors = ['bg-pink-700', 'bg-teal-700', 'bg-slate-600', 'bg-indigo-700', 'bg-emerald-700', 'bg-orange-700'];
              const colorClass = colors[parseInt(email.id) % colors.length] || 'bg-blue-700';

              const isUnread = !email.isRead;

              return (
                <div 
                  key={email.id}
                  onClick={() => onSelectEmail(email)}
                  className={`flex items-start gap-4 p-3 rounded-2xl cursor-pointer transition-colors active:bg-[#303134] md:hover:bg-[#1f1f1f] ${isUnread ? 'bg-[#1e1f20]' : ''}`}
                >
                  {/* Avatar */}
                  <div className={`w-10 h-10 min-w-[40px] rounded-full flex items-center justify-center text-white font-medium text-lg ${colorClass} mt-1`}>
                    {email.logoUrl && !email.logoUrl.includes('random') ? (
                      <img src={email.logoUrl} alt="" className="w-full h-full rounded-full object-cover" />
                    ) : (
                      initial
                    )}
                  </div>
                  
                  <div className="flex-1 min-w-0 pr-1">
                    <div className="flex justify-between items-baseline mb-0.5">
                      <h3 className={`text-[16px] truncate ${isUnread ? 'font-bold text-[#e3e3e3]' : 'font-medium text-[#c4c7c5]'}`}>
                        {email.senderName}
                      </h3>
                      <span className={`text-xs ml-2 whitespace-nowrap ${isUnread ? 'text-[#e3e3e3] font-medium' : 'text-[#8e918f]'}`}>
                        {new Date(email.date).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                      </span>
                    </div>
                    
                    <h4 className={`text-sm truncate leading-snug mb-0.5 ${isUnread ? 'font-bold text-[#e3e3e3]' : 'font-medium text-[#e3e3e3]'}`}>
                      {email.subject}
                    </h4>
                    
                    <div className="flex justify-between items-start">
                      <p className={`text-sm line-clamp-2 leading-snug flex-1 ${isUnread ? 'text-[#c4c7c5]' : 'text-[#8e918f]'}`}>
                        {email.snippet}
                      </p>
                      <button className="text-[#8e918f] ml-2 mt-0.5">
                         <span className="material-symbols-rounded text-[20px]">star_border</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* FAB (Compose) */}
      <button 
        onClick={onCompose}
        className="fixed right-4 bottom-24 md:absolute md:bottom-8 md:right-8 z-30 bg-[#c2e7ff] hover:bg-[#b0d8f5] text-[#001d35] h-14 min-w-[56px] px-4 rounded-2xl shadow-xl flex items-center gap-3 transition-all active:scale-95 group"
      >
        <span className="material-symbols-rounded text-2xl">edit</span>
        <span className="font-medium text-[15px] hidden group-hover:block md:block">Compose</span>
      </button>
    </div>
  );
};

export default EmailList;