import React, { useState, useEffect } from 'react';
import { AppSettings, Account } from '../types';
import * as api from '../services/api';

const SettingsView: React.FC = () => {
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const init = async () => {
      const [accData, setModel] = await Promise.all([
        api.getAccounts(),
        api.getSettings()
      ]);
      setAccounts(accData);
      setSettings(setModel);
      setLoading(false);
    };
    init();
  }, []);

  const handleSwitchAccount = (id: string) => {
    setAccounts(accounts.map(acc => ({
      ...acc,
      isActive: acc.id === id
    })));
  };

  const updateSettings = (newSettings: Partial<AppSettings>) => {
     if (!settings) return;
     const updated = { ...settings, ...newSettings };
     setSettings(updated);
     api.saveSettings(updated);
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const url = URL.createObjectURL(e.target.files[0]);
      updateSettings({ logoUrl: url });
    }
  };

  if (loading || !settings) {
    return <div className="p-4 text-[#8e918f]">Loading settings...</div>;
  }

  return (
    <div className="flex-1 flex flex-col h-full bg-[#111111] overflow-y-auto pb-24 text-[#e3e3e3]">
      {/* Account Switcher (Top) */}
      <div className="bg-[#1e1f20] pt-6 pb-4 px-4 sticky top-0 z-10 border-b border-[#444746]/50">
        <h2 className="text-xs font-medium text-[#8e918f] uppercase tracking-wider mb-3">Accounts</h2>
        <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
          {accounts.map(acc => (
             <div 
               key={acc.id}
               onClick={() => handleSwitchAccount(acc.id)}
               className={`flex flex-col items-center gap-2 min-w-[72px] cursor-pointer transition-opacity ${acc.isActive ? 'opacity-100' : 'opacity-50 hover:opacity-80'}`}
             >
                <div className={`relative p-0.5 rounded-full ${acc.isActive ? 'bg-gradient-to-tr from-[#a8c7fa] to-purple-400' : 'bg-transparent'}`}>
                  {acc.avatar ? (
                    <img src={acc.avatar} alt={acc.name} className="w-14 h-14 rounded-full border-2 border-[#1e1f20]" />
                  ) : (
                    <div className="w-14 h-14 rounded-full border-2 border-[#1e1f20] bg-gray-700 flex items-center justify-center text-xl font-bold">
                        {acc.name.charAt(0)}
                    </div>
                  )}
                  {acc.isActive && (
                    <div className="absolute bottom-0 right-0 bg-[#a8c7fa] text-[#062e6f] rounded-full p-0.5 border-2 border-[#1e1f20]">
                      <span className="material-symbols-rounded text-[14px] block">check</span>
                    </div>
                  )}
                </div>
                <span className="text-xs font-medium text-center truncate w-full">{acc.name}</span>
             </div>
          ))}
          <div className="flex flex-col items-center gap-2 min-w-[72px] cursor-pointer opacity-50 hover:opacity-80">
             <div className="w-14 h-14 rounded-full border border-dashed border-[#8e918f] flex items-center justify-center text-[#8e918f] hover:bg-[#2b2c2f] transition-colors">
               <span className="material-symbols-rounded">add</span>
             </div>
             <span className="text-xs font-medium text-center">Add</span>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-6 max-w-2xl mx-auto w-full">
        
        {/* General Settings */}
        <section>
          <h3 className="text-[#a8c7fa] font-bold text-lg mb-3">General</h3>
          <div className="bg-[#1e1f20] rounded-2xl overflow-hidden border border-[#444746]/50">
            {/* Language */}
            <div className="p-4 flex items-center justify-between border-b border-[#444746]/50">
              <div className="flex items-center gap-3">
                 <span className="material-symbols-rounded text-[#c4c7c5]">language</span>
                 <span>Language / Язык</span>
              </div>
              <div className="flex bg-[#111111] rounded-lg p-1">
                 <button 
                   onClick={() => updateSettings({ language: 'en' })}
                   className={`px-3 py-1 text-xs font-bold rounded-md transition-colors ${settings.language === 'en' ? 'bg-[#2b2c2f] text-[#e3e3e3] shadow-sm' : 'text-[#8e918f]'}`}
                 >EN</button>
                 <button 
                   onClick={() => updateSettings({ language: 'ru' })}
                   className={`px-3 py-1 text-xs font-bold rounded-md transition-colors ${settings.language === 'ru' ? 'bg-[#2b2c2f] text-[#e3e3e3] shadow-sm' : 'text-[#8e918f]'}`}
                 >RU</button>
              </div>
            </div>

            {/* Theme */}
            <div className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                 <span className="material-symbols-rounded text-[#c4c7c5]">contrast</span>
                 <span>Theme</span>
              </div>
              <div className="flex bg-[#111111] rounded-lg p-1">
                 <button 
                   onClick={() => updateSettings({ theme: 'light' })}
                   className={`px-3 py-1 text-xs font-bold rounded-md transition-colors ${settings.theme === 'light' ? 'bg-[#e3e3e3] text-black shadow-sm' : 'text-[#8e918f]'}`}
                 >Light</button>
                 <button 
                   onClick={() => updateSettings({ theme: 'dark' })}
                   className={`px-3 py-1 text-xs font-bold rounded-md transition-colors ${settings.theme === 'dark' ? 'bg-[#2b2c2f] text-[#e3e3e3] shadow-sm' : 'text-[#8e918f]'}`}
                 >Dark</button>
              </div>
            </div>
          </div>
        </section>

        {/* Subscription */}
        <section>
          <h3 className="text-[#a8c7fa] font-bold text-lg mb-3">Subscription</h3>
          <div className="bg-gradient-to-r from-[#2b2c2f] to-[#1e1f20] rounded-2xl p-5 border border-[#444746]/50 flex items-center justify-between">
            <div>
               <p className="text-xs text-[#8e918f] uppercase tracking-wider mb-1">Current Plan</p>
               <h4 className="text-xl font-bold text-white">Pro Plan</h4>
               <p className="text-xs text-[#c4c7c5] mt-1">Renews on Mar 12, 2026</p>
            </div>
            <button className="bg-[#a8c7fa] text-[#062e6f] px-4 py-2 rounded-full text-sm font-bold hover:bg-[#8ab4f8] transition-colors">
              Manage
            </button>
          </div>
        </section>

        {/* AI & Personalization */}
        <section>
           <h3 className="text-[#a8c7fa] font-bold text-lg mb-3">AI Intelligence</h3>
           <div className="bg-[#1e1f20] rounded-2xl p-5 border border-[#444746]/50 space-y-6">
              
              {/* Style Selector */}
              <div>
                 <label className="text-sm text-[#c4c7c5] font-medium block mb-3">AI Personality Style</label>
                 <div className="grid grid-cols-3 gap-2">
                    {[
                      { id: 'strict', label: 'Strict', icon: 'gavel' },
                      { id: 'human', label: 'Human-like', icon: 'face' },
                      { id: 'humor', label: 'Humorous', icon: 'sentiment_very_satisfied' }
                    ].map((style) => (
                       <button
                         key={style.id}
                         onClick={() => updateSettings({ aiStyle: style.id as any })}
                         className={`flex flex-col items-center gap-2 py-3 rounded-xl border transition-all ${
                            settings.aiStyle === style.id 
                              ? 'bg-[#004a77] border-[#004a77] text-[#c2e7ff]' 
                              : 'bg-[#111111] border-[#444746] text-[#8e918f] hover:bg-[#2b2c2f]'
                         }`}
                       >
                          <span className="material-symbols-rounded">{style.icon}</span>
                          <span className="text-xs font-medium">{style.label}</span>
                       </button>
                    ))}
                 </div>
              </div>

              {/* Custom Prompt */}
              <div>
                 <label className="text-sm text-[#c4c7c5] font-medium block mb-2">Custom AI System Prompt</label>
                 <textarea 
                    value={settings.customPrompt}
                    onChange={(e) => updateSettings({ customPrompt: e.target.value })}
                    placeholder="e.g. You are a helpful assistant named Tavelli..."
                    className="w-full bg-[#111111] border border-[#444746] rounded-xl p-3 text-sm text-[#e3e3e3] focus:border-[#a8c7fa] focus:outline-none min-h-[80px]"
                 ></textarea>
              </div>
           </div>
        </section>

        {/* Branding */}
        <section>
           <h3 className="text-[#a8c7fa] font-bold text-lg mb-3">Branding</h3>
           <div className="bg-[#1e1f20] rounded-2xl p-5 border border-[#444746]/50">
              <div className="flex items-start gap-4">
                 <label className="w-20 h-20 rounded-xl border-2 border-dashed border-[#444746] flex flex-col items-center justify-center cursor-pointer hover:bg-[#2b2c2f] transition-colors relative overflow-hidden">
                    {settings.logoUrl ? (
                      <img src={settings.logoUrl} alt="Logo" className="w-full h-full object-contain p-1" />
                    ) : (
                      <>
                        <span className="material-symbols-rounded text-[#8e918f]">upload</span>
                        <span className="text-[10px] text-[#8e918f] mt-1">Logo</span>
                      </>
                    )}
                    <input type="file" accept="image/png, image/jpeg" className="hidden" onChange={handleLogoUpload} />
                 </label>
                 
                 <div className="flex-1">
                    <p className="text-sm font-medium text-[#e3e3e3]">Company Logo</p>
                    <p className="text-xs text-[#8e918f] mt-1 mb-3">Automatically attaches to all AI drafts.</p>
                    
                    <div className="flex items-center gap-3">
                       <span className="text-xs text-[#c4c7c5]">Position:</span>
                       <button 
                         onClick={() => updateSettings({ logoPosition: 'start' })}
                         className={`px-3 py-1 rounded text-xs font-bold transition-colors ${settings.logoPosition === 'start' ? 'bg-[#a8c7fa] text-[#062e6f]' : 'bg-[#111111] text-[#8e918f]'}`}
                       >
                         Start
                       </button>
                       <button 
                         onClick={() => updateSettings({ logoPosition: 'end' })}
                         className={`px-3 py-1 rounded text-xs font-bold transition-colors ${settings.logoPosition === 'end' ? 'bg-[#a8c7fa] text-[#062e6f]' : 'bg-[#111111] text-[#8e918f]'}`}
                       >
                         End
                       </button>
                    </div>
                 </div>
              </div>
           </div>
        </section>
        
        <div className="h-10"></div>
      </div>
    </div>
  );
};

export default SettingsView;