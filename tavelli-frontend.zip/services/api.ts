import { Email, HistoryItem, Account, AppSettings } from '../types';

// In a real production build, this would point to your backend endpoint
const API_BASE_URL = process.env.REACT_APP_API_URL || '/api';

/**
 * API Service
 * 
 * Currently configured to return empty states or defaults until 
 * the backend endpoints are fully implemented.
 */

export const getEmails = async (): Promise<Email[]> => {
  try {
    // Production: const response = await fetch(`${API_BASE_URL}/emails`);
    // return await response.json();
    
    // Return empty array for production initial state (waiting for backend)
    return []; 
  } catch (error) {
    console.error("Failed to fetch emails", error);
    return [];
  }
};

export const getHistory = async (): Promise<HistoryItem[]> => {
  try {
    // Production: const response = await fetch(`${API_BASE_URL}/history`);
    // return await response.json();
    return [];
  } catch (error) {
    console.error("Failed to fetch history", error);
    return [];
  }
};

export const getAccounts = async (): Promise<Account[]> => {
  try {
    // Production: const response = await fetch(`${API_BASE_URL}/accounts`);
    // return await response.json();
    
    // Return a default shell account so the UI isn't completely broken on first load
    return [
      {
        id: 'default',
        name: 'User',
        email: 'user@example.com',
        avatar: '', // UI handles empty avatar
        isActive: true
      }
    ];
  } catch (error) {
    console.error("Failed to fetch accounts", error);
    return [];
  }
};

export const getSettings = async (): Promise<AppSettings> => {
  // Return default settings
  return {
    language: 'en',
    theme: 'dark',
    aiStyle: 'human',
    customPrompt: '',
    logoUrl: null,
    logoPosition: 'end'
  };
};

export const saveSettings = async (settings: AppSettings): Promise<boolean> => {
  // Production: await fetch(`${API_BASE_URL}/settings`, { method: 'POST', body: JSON.stringify(settings) });
  console.log('Settings saved:', settings);
  return true;
};
