import { GoogleGenAI } from "@google/genai";
import { Email, AIAnalysisResult } from "../types";

const API_KEY = process.env.API_KEY || '';

let ai: GoogleGenAI | null = null;

if (API_KEY) {
  try {
    ai = new GoogleGenAI({ apiKey: API_KEY });
  } catch (e) {
    console.error("Failed to initialize Gemini client", e);
  }
}

/**
 * Analyzes an email content using Gemini API.
 */
export const analyzeEmail = async (email: Email): Promise<AIAnalysisResult> => {
  if (!ai) {
    console.warn("Gemini API Key is missing. Returning empty analysis.");
    return {
      sentiment: 'neutral',
      summary: 'AI Analysis unavailable (Missing API Key).',
      suggestedReply: undefined,
      actionButtons: []
    };
  }

  try {
    const model = ai.models; 
    const prompt = `
      Analyze the following email. 
      1. Summarize it in 2 sentences.
      2. Determine sentiment (positive, neutral, negative, urgent).
      3. Identify actionable items:
         - If verification code (4-8 digits), type='copy_code'.
         - If verification link, type='verify_link'.
         - If it needs a reply, suggest 'draft_reply'.
      
      Return ONLY valid JSON in this format:
      {
        "summary": "string",
        "sentiment": "string",
        "actionButtons": [
          { "label": "string", "type": "copy_code"|"verify_link"|"draft_reply"|"unsubscribe", "value": "string", "primary": boolean }
        ]
      }

      Email Subject: ${email.subject}
      Email Body: ${email.snippet}
    `;

    const response = await model.generateContent({
      model: 'gemini-2.5-flash-latest', 
      contents: prompt,
      config: {
        responseMimeType: 'application/json'
      }
    });

    const text = response.text;
    if (text) {
      const result = JSON.parse(text) as AIAnalysisResult;
      return result;
    }
  } catch (e) {
    console.error("AI call failed", e);
  }

  // Fallback if AI fails
  return {
    sentiment: 'neutral',
    summary: 'Could not analyze email content.',
    actionButtons: []
  };
};

export const generateDraft = async (email: Email, tone: string): Promise<string> => {
  if (!ai) return "API Key missing.";

  try {
    const model = ai.models;
    const response = await model.generateContent({
      model: 'gemini-2.5-flash-latest',
      contents: `Draft a reply to this email. Tone: ${tone}. Email context: ${email.snippet}`,
    });
    return response.text || "Failed to generate draft.";
  } catch (e) {
    console.error(e);
    return "Error generating draft.";
  }
};

export const generateNewEmailDraft = async (prompt: string): Promise<{subject: string, body: string}> => {
  if (!ai) return { subject: '', body: 'API Key missing.' };

  try {
    const model = ai.models;
    const response = await model.generateContent({
      model: 'gemini-2.5-flash-latest',
      contents: `Write a new email based on this prompt: "${prompt}". Return JSON with "subject" and "body" fields.`,
      config: { responseMimeType: 'application/json' }
    });
    
    if (response.text) {
      return JSON.parse(response.text);
    }
  } catch (e) {
    console.error(e);
  }
  
  return {
    subject: 'Draft',
    body: 'Could not generate email.'
  };
};