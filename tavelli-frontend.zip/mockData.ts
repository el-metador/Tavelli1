// Mock data removed for production. 
// See services/api.ts for data fetching implementation.
export const MOCK_EMAILS = [];
export const MOCK_HISTORY = [];
export const MOCK_ACCOUNTS = [];