import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import EmailList from './components/EmailList';
import EmailView from './components/EmailView';
import HistoryView from './components/HistoryView';
import SettingsView from './components/SettingsView';
import PricingModal from './components/PricingModal';
import ComposeModal from './components/ComposeModal';
import { Email, UserPlan } from './types';
import * as api from './services/api';

const App: React.FC = () => {
  const [currentPlan, setCurrentPlan] = useState<UserPlan>({ type: 'FREE', price: 0, features: [] });
  const [activeTab, setActiveTab] = useState('inbox');
  const [activeView, setActiveView] = useState<'mail' | 'history' | 'settings'>('mail');
  
  const [selectedEmail, setSelectedEmail] = useState<Email | null>(null);
  const [strictMode, setStrictMode] = useState(false);
  const [isPricingOpen, setIsPricingOpen] = useState(false);
  const [isComposeOpen, setIsComposeOpen] = useState(false);
  const [emails, setEmails] = useState<Email[]>([]);
  const [isProcessing, setIsProcessing] = useState(true);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Fetch Emails from API
  useEffect(() => {
    const fetchData = async () => {
      setIsProcessing(true);
      try {
        const data = await api.getEmails();
        setEmails(data);
      } catch (e) {
        console.error("Error loading emails", e);
      } finally {
        setIsProcessing(false);
      }
    };

    fetchData();
  }, [activeTab]); // Re-fetch if tab changes

  const handleSelectPlan = (type: UserPlan['type']) => {
    setCurrentPlan({ type, price: type === 'PRO' ? 4.5 : type === 'ENTERPRISE' ? 10 : 0, features: [] });
  };

  return (
    <div className="flex h-screen w-full bg-[#111111] overflow-hidden text-[#e3e3e3]">
      {/* Sidebar - Desktop Only */}
      <Sidebar 
        currentPlan={currentPlan}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenPricing={() => setIsPricingOpen(true)}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
      />

      <main className="flex-1 flex flex-col md:flex-row h-full relative">
        {/* Main Content Area */}
        <div className={`flex-1 md:flex md:max-w-md lg:max-w-lg transition-all duration-300 ${selectedEmail ? 'hidden md:flex' : 'flex'}`}>
          
          {/* View Router */}
          {activeView === 'mail' && (
            <EmailList 
              emails={emails} 
              onSelectEmail={setSelectedEmail} 
              strictMode={strictMode} 
              setStrictMode={setStrictMode}
              isProcessing={isProcessing}
              onToggleSidebar={() => setIsSidebarOpen(true)}
              onCompose={() => setIsComposeOpen(true)}
            />
          )}

          {activeView === 'history' && (
            <HistoryView />
          )}

          {activeView === 'settings' && (
            <SettingsView />
          )}

        </div>

        {/* Email Reading Pane (Desktop: Side / Mobile: Overlay) */}
        <div className={`flex-[2] bg-[#111111] md:bg-transparent transition-all duration-300 ${selectedEmail ? 'flex fixed inset-0 z-40 md:static' : 'hidden md:flex'}`}>
          {selectedEmail ? (
            <EmailView email={selectedEmail} onBack={() => setSelectedEmail(null)} />
          ) : (
            <div className="hidden md:flex flex-col items-center justify-center h-full text-gray-500">
              <span className="material-symbols-rounded text-8xl mb-4 text-[#444746]">mark_email_unread</span>
              <p className="text-lg font-medium text-[#444746]">Select an email to view AI insights</p>
            </div>
          )}
        </div>
      </main>

      {/* Persistent Bottom Navigation (Mobile Only) */}
      {!selectedEmail && (
        <div className="h-20 bg-[#1e1f20] flex items-start pt-2 justify-around fixed bottom-0 left-0 right-0 md:hidden z-30 border-t border-[#444746]/50 backdrop-blur-md">
          {/* Mail */}
          <div 
            className={`flex flex-col items-center w-20 cursor-pointer group transition-opacity ${activeView === 'mail' ? 'opacity-100' : 'opacity-60'}`}
            onClick={() => setActiveView('mail')}
          >
            <div className={`px-5 py-1 rounded-full mb-1 transition-all ${activeView === 'mail' ? 'bg-[#004a77] scale-100' : 'scale-95'}`}>
               <span className={`material-symbols-rounded text-[24px] ${activeView === 'mail' ? 'text-[#c2e7ff] filled-icon' : 'text-[#c4c7c5]'}`}>mail</span>
            </div>
            <span className={`text-[12px] font-medium ${activeView === 'mail' ? 'text-[#e3e3e3] font-bold' : 'text-[#c4c7c5]'}`}>Почта</span>
            {/* Badge for Mail - Only show if there are emails */}
            {emails.length > 0 && (
              <span className="absolute top-2 ml-6 bg-[#b3261e] text-white text-[10px] font-bold px-1.5 min-w-[18px] h-[18px] flex items-center justify-center rounded-full border border-[#1e1f20]">
                {emails.filter(e => !e.isRead).length}
              </span>
            )}
          </div>
          
          {/* History */}
          <div 
            className={`flex flex-col items-center w-20 cursor-pointer group transition-opacity ${activeView === 'history' ? 'opacity-100' : 'opacity-60'}`}
            onClick={() => setActiveView('history')}
          >
             <div className={`px-5 py-1 rounded-full mb-1 transition-all ${activeView === 'history' ? 'bg-[#004a77] scale-100' : 'scale-95'}`}>
               <span className={`material-symbols-rounded text-[24px] ${activeView === 'history' ? 'text-[#c2e7ff] filled-icon' : 'text-[#c4c7c5]'}`}>history</span>
             </div>
             <span className={`text-[12px] font-medium ${activeView === 'history' ? 'text-[#e3e3e3] font-bold' : 'text-[#c4c7c5]'}`}>История</span>
          </div>

          {/* Settings */}
          <div 
            className={`flex flex-col items-center w-20 cursor-pointer group transition-opacity ${activeView === 'settings' ? 'opacity-100' : 'opacity-60'}`}
            onClick={() => setActiveView('settings')}
          >
             <div className={`px-5 py-1 rounded-full mb-1 transition-all ${activeView === 'settings' ? 'bg-[#004a77] scale-100' : 'scale-95'}`}>
               <span className={`material-symbols-rounded text-[24px] ${activeView === 'settings' ? 'text-[#c2e7ff] filled-icon' : 'text-[#c4c7c5]'}`}>settings</span>
             </div>
             <span className={`text-[12px] font-medium ${activeView === 'settings' ? 'text-[#e3e3e3] font-bold' : 'text-[#c4c7c5]'}`}>Настройки</span>
          </div>
        </div>
      )}

      <PricingModal 
        isOpen={isPricingOpen} 
        onClose={() => setIsPricingOpen(false)} 
        onSelectPlan={handleSelectPlan}
        currentPlanType={currentPlan.type}
      />
      
      <ComposeModal 
        isOpen={isComposeOpen}
        onClose={() => setIsComposeOpen(false)}
      />
    </div>
  );
};

export default App;